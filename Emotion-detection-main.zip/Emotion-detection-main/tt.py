import cv2
import numpy as np
import pandas as pd
import datetime
from keras.models import load_model
from keras.preprocessing import image
from tensorflow.keras.utils import img_to_array
#import img_to_array
from keras.applications.mobilenet_v2 import preprocess_input
from imutils.video import VideoStream
from imutils.video import FPS
import matplotlib.pyplot as plt
from time import sleep
from datetime import datetime


# Load the trained model
model = load_model('./model/emotion_model.hdf5')

# Load the face detection model
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

# Start the video stream
print("[INFO] Starting video stream...")
vs = VideoStream(src=0).start()
fps = FPS().start()
emotions_array = ('angry', 'disgust', 'fear', 'happy', 'sad', 'surprise', 'neutral')
# Initialize lists to store emotion and timestamp data
emotions = []
timestamps = []
timecur=[]
counter=0
# Loop over the frames from the video stream
while True:
    # Read the next frame from the video stream
    frame = vs.read()
    # Resize the frame to reduce processing time
    frame = cv2.resize(frame, (500, 500))

    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the grayscale frame
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30), flags=cv2.CASCADE_SCALE_IMAGE)

    # Loop over the detected faces
    for (x, y, w, h) in faces:
        # Extract the face ROI and resize it to the input size of the model
        roi = frame[y:y+h, x:x+w]
        roi = cv2.resize(roi, (64, 64))
        roi = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        roi = img_to_array(roi)
        roi = roi.astype('float') / 255.0
        roi = np.expand_dims(roi, axis=0)
        roi = np.expand_dims(roi, axis=-1)

        # Make a prediction on the ROI
        preds = model.predict(roi)[0]
        emotion = np.argmax(preds)
        counter=counter+1
        emotions.append(emotions_array[emotion])
        timestamps.append(counter)
        d = datetime.now()
        timecur.append(d.strftime("%H:%M:%S"))
        # Draw the bounding box around the face and display the emotion label
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.putText(frame, "Emotion: {}".format(emotions_array[emotion]), (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 2)

    # Display the resulting frame
    cv2.imshow("Frame", frame)
    key = cv2.waitKey(1) & 0xFF
    # Break the loop if 'q' key is pressed
    if key == ord("q"):
        break

# Stop the timer and display results
fps.stop()
print("[INFO] Elapsed time: {:.2f}".format(fps.elapsed()))
print("[INFO] FPS: {:.2f}".format(fps.fps()))
print("[INFO] Emotions: ", emotions)
print("[INFO] Timestamps: ", timestamps)


# Create a pandas dataframe from the emotion and timestamp data
df = pd.DataFrame({'Time': timecur, 'Frame': timestamps, 'Response': emotions})
df=df[df['Frame']%5==0]
plt.scatter(df['Frame'], df['Response'])
plt.grid()
plt.xlabel('Frame')
plt.ylabel('Emotion')
plt.title('EMOTION PER FRAME')
plt.savefig('tVe')
plt.show()

group_data = df.groupby(by='Response').count().reset_index()
plt.bar(group_data['Response'], group_data['Frame'])
plt.xlabel('Emotions')
plt.ylabel('Number')
plt.title('NO OF OCCURANCE EMOTIONS')
plt.grid()
plt.savefig('noOfEmotion.png')
plt.show()

import xlsxwriter

workbook = xlsxwriter.Workbook("ExcelReport.xlsx")
worksheet = workbook.add_worksheet()

worksheet.insert_image("D1", "tVe.png")
worksheet.insert_image("D25", "noOfEmotion.png")
worksheet.write_column("A2", df['Frame'].values)
worksheet.write_column("B2", df['Time'].values)
worksheet.write_column("C2", df['Response'].values)
worksheet.write("B1", "Time")
worksheet.write("A1", "Frame")
worksheet.write("C1", "Emotion")
# worksheet.add_table()
workbook.close()

# Save the dataframe to a CSV file
df.to_csv('emotion_data.csv', index=False)

# Cleanup
cv2.destroyAllWindows()
vs.stop()
